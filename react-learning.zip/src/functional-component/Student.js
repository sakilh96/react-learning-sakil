function Student(){
    return (
        <div>
        <h1>Functional Component</h1>
        </div>
    );
}

export default Student