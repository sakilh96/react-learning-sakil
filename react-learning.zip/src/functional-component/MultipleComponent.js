// Multiple components in single page

export function Component1(){
    return (
        <div>
            <h1>I am component1</h1>
        </div>
    );
}

export function Component2(){
    return (
        <div>
            <h1>I am component2</h1>
        </div>
    )
}