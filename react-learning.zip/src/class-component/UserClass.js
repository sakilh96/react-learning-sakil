import React,{Component} from "react";

export default class UserClass extends Component{
    render(){
        return(
            <div>Sakil from User Class component</div>
        )
    }
}
