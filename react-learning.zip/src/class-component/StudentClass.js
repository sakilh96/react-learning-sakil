import React,{Component} from 'react';

export default class StudentClass extends Component{
  render(){
    return(
        <h1>I am student class</h1>
    )
  }
}